﻿v1.0.0.0
- initial version deployed to client

v1.0.0.1 Nov19, 2020
- include president_signature in SETTINGS Form
- include president_signature in CardElement object, saving to database and binding to object
- include president_signature object in Print class

